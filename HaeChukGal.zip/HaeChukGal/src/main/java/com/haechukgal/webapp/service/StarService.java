package com.haechukgal.webapp.service;

import com.haechukgal.webapp.dto.StarDTO;

public interface StarService {
	public void insertStar(StarDTO starDTO);
}
