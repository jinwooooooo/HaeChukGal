package com.haechukgal.webapp.service;

import com.haechukgal.webapp.dto.MemberDTO;

public interface MemberService {
	public void insertMember(MemberDTO memberDTO);
}